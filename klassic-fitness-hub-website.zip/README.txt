# Klassic Fitness Hub – Medipally

A free static website for Klassic Fitness Hub.

## Details
- Location: Medipally, Hyderabad, Telangana
- Landmark: Beside Sampurna Hotel, near Croma, Medipally
- Phone: 09493515735

## Free GitHub Pages setup
1. Create a GitHub account at https://github.com/
2. Create a new **public** repository, for example `klassic-fitness-hub`.
3. Upload **all files and the images folder** from this package.
4. Open the repository's **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**.
6. Select `main` and `/ (root)`, then Save.
7. After GitHub finishes publishing, your free website address will look like:
   `https://YOUR-USERNAME.github.io/klassic-fitness-hub/`

The Google Maps button searches for the gym name/location. If you later have the exact Google Maps listing URL, replace the link in `index.html` for the most precise directions.
